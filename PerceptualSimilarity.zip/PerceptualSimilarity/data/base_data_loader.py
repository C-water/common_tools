
class BaseDataLoader():
    def __init__(self):
        pass
    
    def initialize(self):
        pass

    def load_data():
        return None

        
        
