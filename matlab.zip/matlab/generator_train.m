close all;
clear;

folder = 'D:\project\AIM2019_self\data\Training\original\';

size_input = 128;
size_label = 128;
stride = 128;
%% scale factor
up_scale = [4];

%% downsizing
downsizes = [1];

%% generate data 
filepaths = [];
filepaths = [filepaths; dir(fullfile(folder,'*.jpg'))];
img_num = length(filepaths);

for i = 1 : img_num
    for flip = 1: 3
        for s = 1 : length(up_scale)
            for degree = 1 : 1 
                for downsize = 1 : length(downsizes)
            
                    image_name = filepaths(i).name;
                    image = imread(fullfile(folder,image_name));
                    
                    if flip == 1
                        image = flipdim(image ,1);
                    end
                    if flip == 2
                        image = flipdim(image ,2);
                    end
                    %image = imrotate(image, 90 * (degree - 1));  
                    %image = imresize(image, downsizes(downsize),'bicubic');
                    
                    if size(image,3)==3
                        %image = rgb2ycbcr(image);
                        image_r = im2double(image(:, :, 1));
                        image_g = im2double(image(:, :, 2));
                        image_b = im2double(image(:, :, 3));
                        
                        %image = modcrop(image, up_scale(s));

                        image_label_r = image_r;
                        image_label_g = image_g;
                        image_label_b = image_b;
                        
                        [hei,wid] = size(image_label_r);
            
                        %im_l = imresize(image_label, 1/up_scale(s), 'bicubic');
                        %image_input = imresize(im_l, up_scale(s), 'bicubic');  
                        for x = 1 :stride : hei-size_input+1
                            for y = 1 : stride : wid-size_input+1
                                %subim_input = image_input(x : x+size_input-1, y : y+size_input-1);
                                subim_label_r = image_label_r(x : x+size_label-1, y : y+size_label-1);
                                subim_label_g = image_label_g(x : x+size_label-1, y : y+size_label-1);
                                subim_label_b = image_label_b(x : x+size_label-1, y : y+size_label-1);
                                subim_label(:,:,1) = subim_label_r;
                                subim_label(:,:,2) = subim_label_g;
                                subim_label(:,:,3) = subim_label_b;
                    
                                %image_label = shave(uint8(image_label * 255), [up_scale(s), up_scale(s)]);
                                %image_input = shave(uint8(image_input * 255), [up_scale(s), up_scale(s)]);
        
                                strHR = 'D:\project\AIM2019_self\data\Training_patch_128\original\';
                                %strLR = 'D:\project\VDSR-self\data\train\LR\';
                                %strType = '.bmp';
                                save_HR_image_name = strcat(int2str(x),'_',int2str(y),'_',image_name);
                                %save_LR_image_name = strcat(int2str(x),'_',int2str(y),'_',image_name);
                                save_pathHR = [strHR, save_HR_image_name];
                                %save_pathLR = [strLR, save_LR_image_name];
    
                                imwrite(subim_label,save_pathHR);    
                                %imwrite(subim_input,save_pathLR); 
                            end
                        end
                    end
                end
            end
        end
    end
end
    