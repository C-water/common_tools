close all;
clear;

up_scale = 64; 
file_path = 'D:\project\bokeh-tf1.0\ebb_dataset\Validation_new\original\';
save_path = 'D:\project\bokeh-tf1.0\ebb_dataset\Validation_new\original_modcrop\';

img_path_list = dir(strcat(file_path,'*.png'));
img_num = length(img_path_list);

if img_num > 0 
    for pn = 1:img_num 
        image_name = img_path_list(pn).name;
        i1 =  imread(strcat(file_path,image_name));
        fprintf('%d %s\n',pn,strcat(file_path,image_name));
        i1 = modcrop(i1, up_scale);
        imwrite(i1, strcat(save_path,image_name));
    end
end