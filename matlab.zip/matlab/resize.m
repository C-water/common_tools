close all;
clear;

up_scale = 64; 
file_path = 'D:\project\bokeh-tf1.0\ebb_dataset\test200\original_modcrop\';
save_path_x2 = 'D:\project\bokeh-tf1.0\ebb_dataset\test200\original_modcrop\X2\';
save_path_x4 = 'D:\project\bokeh-tf1.0\ebb_dataset\test200\original_modcrop\X4\';
save_path_x8 = 'D:\project\bokeh-tf1.0\ebb_dataset\test200\original_modcrop\X8\';

img_path_list = dir(strcat(file_path,'*.png'));
img_num = length(img_path_list);

if img_num > 0 
    for pn = 1:img_num 
        image_name = img_path_list(pn).name;
        save_name = image_name(1:end-4);
        %print(str(save_name))
        
        i1 =  imread(strcat(file_path,image_name));
        fprintf('%d %s\n',pn,strcat(file_path,image_name));
        
        i2 = imresize(i1,0.5,'bicubic');
        i4 = imresize(i1,0.25,'bicubic');
        i8 = imresize(i1,0.125,'bicubic');
        
        imwrite(i2, strcat(save_path_x2,save_name,'.png'));
        imwrite(i4, strcat(save_path_x4,save_name,'.png'));
        imwrite(i8, strcat(save_path_x8,save_name,'.png'));
    end
end